import sqlite3
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)
DATABASE = 'notes.db'

def create_db():
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS notes
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, content TEXT, timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
    conn.commit()
    conn.close()

create_db()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/save', methods=['POST'])
@app.route('/save/<int:id>', methods=['POST'])  # Handle saving edited notes
def save(id=None):
    data = request.json
    title = data.get('title')
    content = data.get('content')
    if title and content:
        try:
            conn = sqlite3.connect(DATABASE)
            c = conn.cursor()
            if id:  # If ID is provided, update the existing note
                c.execute("UPDATE notes SET title=?, content=? WHERE id=?", (title, content, id))
            else:  # Otherwise, insert a new note
                c.execute("INSERT INTO notes (title, content) VALUES (?, ?)", (title, content))
            conn.commit()
            conn.close()
            return 'Note saved successfully!', 200
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    else:
        return jsonify({'error': 'Title and content are required.'}), 400

@app.route('/note/<int:id>')
def get_note(id):
    try:
        conn = sqlite3.connect(DATABASE)
        c = conn.cursor()
        c.execute("SELECT title, content FROM notes WHERE id=?", (id,))
        note = c.fetchone()
        conn.close()
        if note:
            return jsonify({'note': note}), 200
        else:
            return jsonify({'error': 'Note not found.'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/list')
def list_notes():
    try:
        conn = sqlite3.connect(DATABASE)
        c = conn.cursor()
        c.execute("SELECT id, title, timestamp FROM notes ORDER BY timestamp DESC")
        notes = c.fetchall()
        conn.close()
        return jsonify({'notes': notes}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
